# PvZ2 CHN 4.2.8 resource catalog

18 RTON manifests from the authentic APK. Includes sources, groups, resources and atlas/subgroup references with original JSON per resource.

This is NOT a verified plant/zombie combat stat, skill, level-wave, or Chinese-display-name database. Those require in-game configuration schemas and localization sources. Every row retains its source filename.
