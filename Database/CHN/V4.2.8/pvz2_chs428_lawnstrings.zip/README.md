# PvZ2 国服 4.2.8 LawnStrings

From the original game-provided key/value table, not generated translations. Original token, text, source line numbers and SHA256 are retained. Name/category hints are only provisional; they are not automatically verified species IDs.
